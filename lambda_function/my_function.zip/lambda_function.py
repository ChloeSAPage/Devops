import json
import psycopg2
import os

print('Loading function')


def lambda_handler(event, context):
        try:
            connection = psycopg2.connect(
                user=os.environ['DB_USER'],
                password=os.environ['DB_PASSWORD'],
                host=os.environ['DB_HOST'],
                port="5432",
                database=os.environ['DB_NAME']
            )

            cursor = connection.cursor()
            cursor.execute("CREATE TABLE proactive (id INTEGER, ip TEXT, flag boolean)")
            cursor.execute("INSERT INTO proactive (id, ip, flag) VALUES (1, '12.00.124', true)")
            cursor.execute("SELECT * FROM proactive")
            results = cursor.fetchall()

            print("Query results:", results)

        except (Exception, psycopg2.Error) as error:
            print("Error while connecting to RDS", error)

        finally:
            if connection:
                cursor.close()
                connection.close()

        return event['id'], event['ip'], event['flag']

